package com.omenterprises.app.util

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

object InvoiceUtil {
    fun generateSampleInvoice(context: Context): String {
        val prefs = context.getSharedPreferences("om_prefs", Context.MODE_PRIVATE)
        val company = prefs.getString("company_name", "OM Enterprises") ?: "OM Enterprises"
        val gst = prefs.getString("gst", "23BRAPS3984DIZQ") ?: "23BRAPS3984DIZQ"
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
        val canvas = page.canvas
        canvas.drawText(company, 40f, 40f, android.graphics.Paint().apply { textSize = 18f })
        canvas.drawText("GSTIN: $gst", 40f, 60f, android.graphics.Paint().apply { textSize = 12f })
        canvas.drawText("Sample Item - Qty 1 - ₹100", 40f, 110f, android.graphics.Paint().apply { textSize = 12f })
        doc.finishPage(page)
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "OMEnterprises")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, "sample_invoice_${'$'}{System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file.absolutePath
    }
}
