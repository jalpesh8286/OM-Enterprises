package com.omenterprises.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.omenterprises.app.databinding.ActivityDashboardBinding
import com.omenterprises.app.util.InvoiceUtil

class DashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnSampleInvoice.setOnClickListener {
            val path = InvoiceUtil.generateSampleInvoice(this)
            Toast.makeText(this, "Saved: $path", Toast.LENGTH_LONG).show()
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}
