package com.omenterprises.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.omenterprises.app.databinding.ActivitySettingsBinding
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val prefs = getSharedPreferences("om_prefs", Context.MODE_PRIVATE)
        binding.etCompanyName.setText(prefs.getString("company_name", "OM Enterprises"))
        binding.etGst.setText(prefs.getString("gst", "23BRAPS3984DIZQ"))
        binding.etAddress.setText(prefs.getString("address", ""))

        val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val uri = r.data?.data
                uri?.let {
                    val input = contentResolver.openInputStream(it)
                    val dir = File(getExternalFilesDir(null), "logo")
                    if (!dir.exists()) dir.mkdirs()
                    val out = File(dir, "logo.png")
                    FileOutputStream(out).use { output -> input?.copyTo(output) }
                    prefs.edit().putString("logo_path", out.absolutePath).apply()
                    Toast.makeText(this, "Logo saved", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnChooseLogo.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pick.launch(intent)
        }

        binding.btnSave.setOnClickListener {
            prefs.edit().putString("company_name", binding.etCompanyName.text.toString().trim())
                .putString("gst", binding.etGst.text.toString().trim())
                .putString("address", binding.etAddress.text.toString().trim())
                .apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
