package com.omenterprises.app;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        TextView tv = new TextView(this);
        tv.setText("OM Enterprises");
        tv.setTextSize(22);
        ll.addView(tv);
        Button b = new Button(this);
        b.setText("Open Dashboard");
        b.setOnClickListener(v -> startActivity(new Intent(this, com.omenterprises.app.ui.DashboardActivity.class)));
        ll.addView(b);
        setContentView(ll);
    }
}
