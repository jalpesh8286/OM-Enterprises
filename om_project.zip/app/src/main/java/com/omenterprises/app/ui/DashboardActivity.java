package com.omenterprises.app.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        TextView tv = new TextView(this);
        tv.setText("Dashboard - OM Enterprises");
        ll.addView(tv);
        Button b = new Button(this);
        b.setText("Generate Sample Invoice");
        ll.addView(b);
        setContentView(ll);
    }
}
